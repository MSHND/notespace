"""One-shot synthetic P349 OAuth switch isolation; no production service or publication.

Uses the unchanged P349 browser prototype solely for localhost WebAuthn registration,
actual Chromium credentials and its disposable credential records. The protected
OAuth verified-subject resolver is imported from the EXISTING repository by Node.
"""
import base64
import hashlib
import json
import pathlib
import secrets
import socket
import sqlite3
import struct
import subprocess
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, utils
from playwright.sync_api import sync_playwright

import sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'p349-browser-disposable'))
from prototype import App, b64, ub64

ROOT = pathlib.Path(__file__).resolve().parents[2]
ISSUER = 'https://issuer.synthetic.invalid/'
AUDIENCE = 'urn:synthetic:p349'
RESOURCE_URL = 'https://pocket.synthetic.invalid/project-documents'
CONFIG = {'issuer': ISSUER, 'audience': AUDIENCE,
          'jwksUrl': 'https://issuer.synthetic.invalid/.well-known/jwks.json',
          'resourceUrl': RESOURCE_URL}

# This is an in-process test adapter around the actual, unchanged production
# verified-subject binding module. The injected verifier verifies JWS P-256,
# not caller-provided claims, and no internet identity provider is contacted.
NODE_BINDING = r'''
const fs=require('fs'), crypto=require('crypto');
const {createProjectDocumentsTokenVerifier}=require('./sync-service/pocket-project-documents-auth.js');
const {createHandoverVerifiedSubjectBinding}=require('./sync-service/pocket-handover-verified-subject-binding.js');
(async()=>{
 const req=JSON.parse(fs.readFileSync(0,'utf8'));
 const bridge=createHandoverVerifiedSubjectBinding({readApprovedPolicy:async()=>req.policy});
 let trusted=null;
 const verifier=createProjectDocumentsTokenVerifier({config:req.config,
  verifyJwt:async(token)=>{
   const parts=token.split('.'); if(parts.length!==3)throw Error('token-shape');
   const head=JSON.parse(Buffer.from(parts[0],'base64url').toString('utf8'));
   if(head.alg!=='ES256'||head.typ!=='JWT')throw Error('jwt-header');
   const signature=Buffer.from(parts[2],'base64url');
   if(signature.length!==64||!crypto.verify('sha256',Buffer.from(parts[0]+'.'+parts[1]),
      {key:req.publicKey,dsaEncoding:'ieee-p1363'},signature))throw Error('jwt-signature');
   return JSON.parse(Buffer.from(parts[1],'base64url').toString('utf8'));
  },
  verifiedSubjectObserver(auth,claims){bridge.verifiedSubjectObserver(auth,claims);trusted=claims;}});
 const auth=await verifier.verifyAccessToken(req.token);
 if(!trusted||typeof trusted.subject!=='string'||!trusted.subject||trusted.subject.endsWith('@clients'))throw Error('not-human');
 if(req.mode==='verify')return console.log(JSON.stringify({ok:true,issuer:trusted.issuer,subject:trusted.subject}));
 const principal=await bridge.resolvePrincipal(auth);
 console.log(JSON.stringify({ok:true,issuer:trusted.issuer,subject:trusted.subject,principal}));
})().catch(()=>{console.log(JSON.stringify({ok:false}));});
'''


def port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def jwt_sign(private, sub):
    head = b64(json.dumps({'alg':'ES256','typ':'JWT'},separators=(',',':')).encode())
    data = b64(json.dumps({'iss':ISSUER,'aud':AUDIENCE,'sub':sub,
                            'exp':int(time.time())+900,'iat':int(time.time()),
                            'scope':'openid'},separators=(',',':')).encode())
    signed = (head+'.'+data).encode()
    der = private.sign(signed, ec.ECDSA(hashes.SHA256()))
    rr, ss = utils.decode_dss_signature(der)
    return head+'.'+data+'.'+b64(rr.to_bytes(32,'big')+ss.to_bytes(32,'big'))


class Gate:
    """Synthetic server-owned authority, kept separate from browser token inputs."""
    def __init__(self, app, context, origin, public_key):
        self.app, self.context, self.origin = app, context, origin
        self.public_key = public_key
        self.sessions, self.pending, self.binding = {}, {}, None
        self.capabilities, self.challenges = {}, {}
        self.lock = threading.RLock()
        self.consent_events = 0
        self.verifications = {'login':0,'consent':0,'confirmation':0}
        self.publication_dispatches = 0
        with self.app.conn() as db:
            db.execute('''CREATE TABLE switch_approval_receipts (
             id TEXT PRIMARY KEY, intent_id TEXT NOT NULL UNIQUE,
             issuer TEXT NOT NULL, subject TEXT NOT NULL, pocket_account TEXT NOT NULL,
             owner_id TEXT NOT NULL, resource_id TEXT NOT NULL, release_id TEXT NOT NULL,
             expected_revision INTEGER NOT NULL, manifest TEXT NOT NULL,
             credential_id TEXT NOT NULL)''')
            row = db.execute('SELECT * FROM intent').fetchone()
            self.frozen = tuple(row[x] for x in ('account','owner','resource','release','expected_rev','docs','manifest'))

    def policy(self):
        return {'version':1,'approved':True,'revoked':False,
                'bindings':[dict(self.binding)] if self.binding is not None else []}

    def oauth(self, token, mode='resolve'):
        request = {'mode':mode,'token':token,'config':CONFIG,'policy':self.policy(),
                   'publicKey':self.public_key}
        out = subprocess.run(['node','-e',NODE_BINDING],input=json.dumps(request),text=True,
                             capture_output=True,cwd=ROOT,timeout=10,check=True)
        result = json.loads(out.stdout.strip())
        if result.get('ok') is not True:
            raise PermissionError('verified-oauth-or-owner-binding-denied')
        return result

    def session_account(self):
        matches = [cookie['value'] for cookie in self.context.cookies([self.origin])
                   if cookie['name']=='p349-pocket-session']
        return self.sessions.get(matches[0]) if len(matches)==1 else None

    def assert_session(self):
        account = self.session_account()
        if account is None:
            raise PermissionError('Pocket-session-not-authenticated')
        return account

    def start(self, purpose, account, oauth=None, pending=None, capability=None):
        with self.app.conn() as db:
            ids = [row['id'] for row in db.execute('SELECT id FROM credential WHERE account=?',(account,))]
        if len(ids)!=1:
            raise PermissionError('unregistered-pocket-credential')
        challenge_id='ch-'+secrets.token_hex(16)
        challenge=b64(secrets.token_bytes(32))
        self.challenges[challenge_id]={'purpose':purpose,'account':account,
            'nonce':challenge,'used':False,'oauth':oauth,'pending':pending,
            'capability':capability,'manifest':self.frozen[-1]}
        return {'challengeId':challenge_id,'challenge':challenge,'rpId':'localhost',
                'allowCredentials':[{'id':ids[0]}]}

    def verify_assertion(self, challenge_id, credential):
        challenge = self.challenges.get(challenge_id)
        if not challenge or challenge['used']:
            raise PermissionError('challenge-missing-or-used')
        if credential.get('id') != credential.get('rawId') or credential.get('type') != 'public-key':
            raise PermissionError('credential-shape')
        raw=ub64(credential['response']['clientDataJSON'])
        client=json.loads(raw)
        auth_data=ub64(credential['response']['authenticatorData'])
        signature=ub64(credential['response']['signature'])
        if client.get('type')!='webauthn.get' or client.get('challenge')!=challenge['nonce'] \
           or client.get('origin')!=self.origin or client.get('crossOrigin',False):
            raise PermissionError('client-data')
        if len(auth_data)<37 or auth_data[:32]!=hashlib.sha256(b'localhost').digest() \
           or (auth_data[32]&0x05)!=0x05:
            raise PermissionError('rp-up-uv')
        with self.app.conn() as db:
            row=db.execute('SELECT * FROM credential WHERE id=?',(credential['id'],)).fetchone()
        if not row or row['account']!=challenge['account']:
            raise PermissionError('credential-account-mismatch')
        counter=struct.unpack('>I',auth_data[33:37])[0]
        if (counter or row['counter']) and counter<=row['counter']:
            raise PermissionError('signature-counter-replay')
        key=ec.EllipticCurvePublicNumbers(int.from_bytes(row['public_x'],'big'),
            int.from_bytes(row['public_y'],'big'),ec.SECP256R1()).public_key()
        key.verify(signature,auth_data+hashlib.sha256(raw).digest(),ec.ECDSA(hashes.SHA256()))
        challenge['used']=True
        with self.app.conn() as db:
            db.execute('UPDATE credential SET counter=? WHERE id=?',(counter,credential['id']))
        self.verifications[challenge['purpose']]+=1
        return row['account'], credential['id']

    def finish_login(self, challenge_id, assertion):
        if self.challenges[challenge_id]['purpose']!='login':
            raise PermissionError('wrong-ceremony')
        account,_=self.verify_assertion(challenge_id,assertion)
        ticket='session-'+secrets.token_hex(24)
        self.sessions[ticket]=account
        self.context.add_cookies([{'name':'p349-pocket-session','value':ticket,
            'url':self.origin,'httpOnly':True,'sameSite':'Strict'}])
        return account

    def pending_link(self, token):
        identity=self.oauth(token,'verify')
        with self.app.conn() as db:
            release=db.execute('SELECT account,resource FROM intent').fetchone()
        link_id='pending-'+secrets.token_hex(16)
        self.pending[link_id]={'issuer':identity['issuer'],'subject':identity['subject'],
            'account':release['account'],'resource':release['resource'],'approved':False}
        return link_id

    def begin_consent(self, token, link_id):
        identity=self.oauth(token,'verify')
        pending=self.pending.get(link_id)
        if not pending or pending['approved'] or (identity['issuer'],identity['subject']) != \
                (pending['issuer'],pending['subject']) or self.assert_session()!=pending['account']:
            raise PermissionError('link-identity-or-pocket-owner-mismatch')
        return self.start('consent',pending['account'],oauth=(identity['issuer'],identity['subject']),pending=link_id)

    def approve_link(self, token, challenge_id, assertion):
        identity=self.oauth(token,'verify')
        ch=self.challenges[challenge_id]
        link=self.pending[ch['pending']]
        if ch['purpose']!='consent' or link['approved'] or self.assert_session()!=link['account'] \
           or (identity['issuer'],identity['subject'])!=ch['oauth']:
            raise PermissionError('consent-mismatched')
        account,_=self.verify_assertion(challenge_id,assertion)
        if account!=link['account']:
            raise PermissionError('consent-credential-mismatch')
        with self.app.conn() as db:
            intent=db.execute('SELECT * FROM intent').fetchone()
        if intent['account']!=account or intent['resource']!=link['resource']:
            raise PermissionError('server-owned-resource-mismatch')
        self.binding={'issuer':identity['issuer'],'subject':identity['subject'],
            'audience':AUDIENCE,'resourceUrl':RESOURCE_URL,'ownerId':intent['owner'],
            'resourceId':intent['resource'],'principalId':'principal-alice',
            'role':'publisher','capabilities':['read','publish'],'approved':True,
            'ownerApproved':True,'revoked':False,'expiresAtMs':int(time.time()*1000)+600000}
        link['approved']=True
        self.consent_events+=1

    def resolve(self, token):
        identity=self.oauth(token,'resolve')
        principal=identity['principal']
        with self.app.conn() as db:
            intent=db.execute('SELECT account,owner,resource FROM intent').fetchone()
        if principal['ownerId']!=intent['owner'] or principal['resourceId']!=intent['resource']:
            raise PermissionError('resource-not-authorised')
        cap='cap'+secrets.token_hex(16)
        self.capabilities[cap]={'issuer':identity['issuer'],'subject':identity['subject'],
            'account':intent['account'],'owner':principal['ownerId'],'resource':principal['resourceId'],
            'operation':'publish','expires':time.time()+30}
        return {'capability':cap,'owner':principal['ownerId'],'resource':principal['resourceId']}

    def check_cap(self, token, cap):
        identity=self.oauth(token,'resolve')
        record=self.capabilities.get(cap)
        if not record or record['expires']<=time.time() or (identity['issuer'],identity['subject']) \
           != (record['issuer'],record['subject']) or record['operation']!='publish' \
           or identity['principal']['ownerId']!=record['owner'] \
           or identity['principal']['resourceId']!=record['resource']:
            raise PermissionError('capability-not-authorised')
        return record

    def begin_confirm(self, token, cap):
        record=self.check_cap(token,cap)
        if self.assert_session()!=record['account'] or self.receipts()!=0:
            raise PermissionError('session-or-prior-approval')
        return self.start('confirmation',record['account'],
                          oauth=(record['issuer'],record['subject']),capability=cap)

    def complete_confirm(self, token, cap, challenge_id, assertion):
        with self.lock:
            record=self.check_cap(token,cap)
            ch=self.challenges.get(challenge_id)
            if not ch or ch['purpose']!='confirmation' or ch['capability']!=cap \
               or ch['oauth']!=(record['issuer'],record['subject']) or self.assert_session()!=record['account'] \
               or ch['manifest']!=self.frozen[-1]:
                raise PermissionError('fresh-intent-confirmation-required')
            account,credential_id=self.verify_assertion(challenge_id,assertion)
            if account!=record['account']:
                raise PermissionError('owner-credential-mismatch')
            with self.app.conn() as db:
                intent=db.execute('SELECT * FROM intent').fetchone()
                current=tuple(intent[x] for x in ('account','owner','resource','release','expected_rev','docs','manifest'))
                if current!=self.frozen or intent['account']!=record['account']:
                    raise PermissionError('frozen-intent-changed')
                db.execute('''INSERT INTO switch_approval_receipts VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
                    ('ap'+secrets.token_hex(16),intent['id'],record['issuer'],record['subject'],
                    account,record['owner'],record['resource'],intent['release'],intent['expected_rev'],
                    intent['manifest'],credential_id))
            return 'APPROVED'

    def receipts(self):
        with self.app.conn() as db:
            return db.execute('SELECT COUNT(*) FROM switch_approval_receipts').fetchone()[0]

    def frozen_now(self):
        with self.app.conn() as db:
            intent=db.execute('SELECT * FROM intent').fetchone()
            return tuple(intent[x] for x in ('account','owner','resource','release','expected_rev','docs','manifest'))


REG_JS = r'''async v=>{
 const b=s=>Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4)),x=>x.charCodeAt(0));
 const e=x=>btoa(String.fromCharCode(...new Uint8Array(x))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=/g,'');
 const pub={...v,challenge:b(v.challenge),user:{...v.user,id:b(v.user.id)}};
 const c=await navigator.credentials.create({publicKey:pub});
 return {id:c.id,response:{attestationObject:e(c.response.attestationObject)}};
}'''
AUTH_JS = r'''async begin=>{
 const b=s=>Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4)),x=>x.charCodeAt(0));
 const e=x=>btoa(String.fromCharCode(...new Uint8Array(x))).replace(/\+/g,'-').replace(/\//g,'');
 const opts={challenge:b(begin.challenge),rpId:begin.rpId,
  allowCredentials:begin.allowCredentials.map(x=>({type:'public-key',id:b(x.id)})),
  userVerification:'required',timeout:10000};
 if('extensions' in opts)throw Error('NO_PRF_BREACH');
 const c=await navigator.credentials.get({publicKey:opts});
 return {id:c.id,rawId:e(c.rawId),type:c.type,response:{
  clientDataJSON:e(c.response.clientDataJSON),authenticatorData:e(c.response.authenticatorData),
  signature:e(c.response.signature),userHandle:c.response.userHandle?e(c.response.userHandle):null}};
}'''


class RegistrationOnlyHandler(BaseHTTPRequestHandler):
    """No review/approval/publish endpoints from the earlier browser prototype."""
    def log_message(self,*args):
        pass
    def reply(self, data, code=200):
        body=json.dumps(data).encode()
        self.send_response(code)
        self.send_header('Content-Type','application/json')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        if self.path!='/':
            return self.reply({'status':'DENIED'},404)
        body=b'<!doctype html><html lang="en"><title>P349 isolated WebAuthn test</title><body>Disposable, no publication endpoint.</body></html>'
        self.send_response(200)
        self.send_header('Content-Type','text/html; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def do_POST(self):
        if self.headers.get('Origin')!=self.server.app.origin or self.headers.get('Content-Type')!='application/json':
            return self.reply({'status':'DENIED'},403)
        if self.path not in ('/__test/register-options','/__test/register-finish'):
            return self.reply({'status':'DENIED'},404)
        try:
            length=int(self.headers.get('Content-Length','-1'))
            if not 0<=length<=8192:raise ValueError('size')
            data=json.loads(self.rfile.read(length))
        except Exception:
            return self.reply({'status':'DENIED'},400)
        acct=self.server.app.session(self.headers)
        if acct!='acct-alice':
            return self.reply({'status':'DENIED'},403)
        if self.path.endswith('/register-options'):
            return self.reply(self.server.app.registration(acct))
        return self.reply(self.server.app.register(acct,data))


class OneOAuthSwitch(unittest.TestCase):
    def test_one_ordered_account_switch(self):
        with tempfile.TemporaryDirectory(prefix='p349-oauth-switch-') as folder:
            server=None
            with sync_playwright() as playwright:
                browser=None
                try:
                    number=port()
                    origin=f'http://localhost:{number}'
                    app=App(pathlib.Path(folder)/'synthetic.sqlite',origin)
                    server=ThreadingHTTPServer(('127.0.0.1',number),RegistrationOnlyHandler)
                    server.app=app
                    thread=threading.Thread(target=server.serve_forever,daemon=True)
                    thread.start()
                    browser=playwright.chromium.launch(executable_path='/usr/bin/chromium',headless=True,
                                                      args=['--no-sandbox'])
                    ctx=browser.new_context(base_url=origin)
                    ctx.add_cookies([{'name':'p349test','value':'session-alice','url':origin}])
                    page=ctx.new_page()
                    page.goto(origin)
                    cdp=ctx.new_cdp_session(page)
                    cdp.send('WebAuthn.enable')
                    cdp.send('WebAuthn.addVirtualAuthenticator',{'options':{
                        'protocol':'ctap2','transport':'usb','hasResidentKey':True,
                        'hasUserVerification':True,'isUserVerified':True,
                        'automaticPresenceSimulation':True}})
                    def browser_api(path,body={}):
                        return page.evaluate('''async a=>{
                           const r=await fetch(a.path,{method:'POST',headers:{'Content-Type':'application/json'},
                           credentials:'same-origin',body:JSON.stringify(a.body)});return r.json();
                        }''',{'path':path,'body':body})
                    reg=browser_api('/__test/register-options')
                    credential=page.evaluate(REG_JS,reg)
                    self.assertEqual(browser_api('/__test/register-finish',credential)['status'],'REGISTERED')
                    self.assertNotIn('prf',json.dumps(reg).lower())
                    private=ec.generate_private_key(ec.SECP256R1())
                    public=private.public_key().public_bytes(serialization.Encoding.PEM,
                                           serialization.PublicFormat.SubjectPublicKeyInfo).decode()
                    gate=Gate(app,ctx,origin,public)
                    a=jwt_sign(private,'human-a')
                    b=jwt_sign(private,'human-b')
                    tampered=a.split('.')
                    forged_payload={'iss':ISSUER,'aud':AUDIENCE,'sub':'human-b',
                                    'exp':int(time.time())+900,'scope':'openid'}
                    tampered[1]=b64(json.dumps(forged_payload).encode())
                    with self.assertRaises(PermissionError):gate.oauth('.'.join(tampered),'verify')
                    print('P349_SWITCH_OAUTH_JWS=PASS; ES256 synthetic signed A/B; tamper denied',flush=True)

                    # Pocket authenticates independently via an actual signed/UV assertion.
                    login=gate.start('login','acct-alice')
                    assertion=page.evaluate(AUTH_JS,login)
                    self.assertEqual(gate.finish_login(login['challengeId'],assertion),'acct-alice')
                    self.assertEqual(gate.session_account(),'acct-alice')
                    print('P349_SWITCH_POCKET_LOGIN=PASS; genuine Chromium UV WebAuthn; server ES256 verified',flush=True)

                    # Pending OAuth link grants zero rights; B cannot use A's request.
                    pending=gate.pending_link(a)
                    self.assertEqual(gate.receipts(),0)
                    self.assertEqual(len(gate.capabilities),0)
                    with self.assertRaises(PermissionError):gate.resolve(a)
                    with self.assertRaises(PermissionError):gate.begin_consent(b,pending)
                    consent=gate.begin_consent(a,pending)
                    owner_action=page.evaluate(AUTH_JS,consent)
                    gate.approve_link(a,consent['challengeId'],owner_action)
                    self.assertEqual(gate.consent_events,1)
                    authorised=gate.resolve(a)
                    self.assertEqual(authorised['resource'],'synthetic-handover')
                    self.assertEqual(authorised['owner'],'owner-alice')
                    self.assertEqual(gate.receipts(),0)
                    self.assertEqual(len(gate.capabilities),1)
                    print('P349_SWITCH_PHASE_1=PASS; pending=0 grants; explicit signed owner consent=1; A capabilities=1; receipts=0',flush=True)

                    # The *same* Pocket A cookie persists while OAuth requester changes to B.
                    session_before=next(c['value'] for c in ctx.cookies([origin]) if c['name']=='p349-pocket-session')
                    self.assertEqual(gate.session_account(),'acct-alice')
                    self.assertEqual(gate.oauth(b,'verify')['subject'],'human-b')
                    with self.assertRaises(PermissionError):gate.resolve(b)
                    with self.assertRaises(PermissionError):gate.check_cap(b,authorised['capability'])
                    with self.assertRaises(PermissionError):gate.begin_confirm(b,authorised['capability'])
                    with self.assertRaises(PermissionError):gate.begin_consent(b,pending)
                    self.assertEqual(gate.receipts(),0)
                    self.assertEqual(sum(x['subject']=='human-b' for x in gate.capabilities.values()),0)
                    self.assertEqual(gate.session_account(),'acct-alice')
                    session_after=next(c['value'] for c in ctx.cookies([origin]) if c['name']=='p349-pocket-session')
                    self.assertEqual(session_before,session_after)
                    print('P349_SWITCH_PHASE_2=PASS; B capabilities=0; B receipts=0; A Pocket session remains valid and identical; B publish=DENIED',flush=True)

                    # OAuth A returns: valid link != automatic publication approval.
                    again=gate.resolve(a)
                    self.assertEqual(again['resource'],'synthetic-handover')
                    self.assertEqual(gate.receipts(),0)
                    self.assertEqual(gate.verifications['confirmation'],0)
                    start=gate.begin_confirm(a,again['capability'])
                    self.assertEqual(gate.receipts(),0)
                    signed=page.evaluate(AUTH_JS,start)
                    self.assertNotIn('prf',json.dumps(signed).lower())
                    self.assertNotIn('extensions',json.dumps(signed).lower())
                    self.assertEqual(gate.complete_confirm(a,again['capability'],start['challengeId'],signed),'APPROVED')
                    self.assertEqual(gate.receipts(),1)
                    with self.assertRaises(PermissionError):
                        gate.complete_confirm(a,again['capability'],start['challengeId'],signed)
                    with self.assertRaises(PermissionError):gate.begin_confirm(b,again['capability'])
                    self.assertEqual(gate.receipts(),1)
                    self.assertEqual(gate.frozen_now(),gate.frozen)
                    self.assertEqual(len(json.loads(gate.frozen[-2])),9)
                    with app.conn() as db:
                        receipt=db.execute('SELECT * FROM switch_approval_receipts').fetchone()
                        self.assertEqual(tuple(receipt[x] for x in ('issuer','subject','pocket_account','owner_id','resource_id','release_id','expected_revision','manifest')),
                            (ISSUER,'human-a','acct-alice','owner-alice','synthetic-handover',
                             'synthetic-release-17',7,gate.frozen[-1]))
                        self.assertEqual(db.execute('SELECT count(*) FROM receipts').fetchone()[0],0)
                    self.assertEqual(gate.publication_dispatches,0)
                    self.assertEqual(gate.verifications,{'login':1,'consent':1,'confirmation':1})
                    print('P349_SWITCH_PHASE_3=PASS; return A pre-confirm receipts=0; signed fresh UV confirm=1; final receipts=1; replay denied',flush=True)
                    print('P349_SWITCH_FROZEN=PASS; nine immutable docs, exact owner/resource/release/revision/digest, no dispatch',flush=True)
                    print('P349_SWITCH_NO_PRF=PASS; 3 Chromium assertions omit extensions/prf; no Pocket crypto',flush=True)
                    print('P349_SWITCH_TOTAL=PASS; single ordered acceptance scenario',flush=True)
                finally:
                    if browser is not None:browser.close()
                    if server is not None:
                        server.shutdown()
                        server.server_close()

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(OneOAuthSwitch)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() and result.testsRun==1 else 1)

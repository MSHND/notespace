import test from 'node:test';
import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import fs from 'node:fs/promises';
import os from 'node:os';

const BASE = pathToFileURL(path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'index.html')).href;
const engines = ['yjs', 'automerge'];
const pageURL = engine => `${BASE}?engine=${engine}`;
const H = (page, fn, args) => page.evaluate(([fnName, argumentsArray]) => window.pocketResearch[fnName](...argumentsArray), [fn, args ?? []]);
const state = page => H(page, 'state');
async function newPage(browser, engine) {
  const context = await browser.newContext({acceptDownloads:false});
  const page = await context.newPage();
  await page.goto(pageURL(engine));
  await page.waitForFunction(() => Boolean(window.pocketResearch));
  return {context, page};
}
async function select(page, substring) {
  await page.locator('#body').evaluate((el, needle) => {
    const index = el.value.indexOf(needle);
    if (index < 0) throw Error(`Missing selection ${needle}`);
    el.focus();
    el.setSelectionRange(index, index + needle.length);
  }, substring);
}
async function moveCaret(page, position) {
  await page.locator('#body').evaluate((el, where) => {
    el.focus();
    const index = where === 'end' ? el.value.length : 0;
    el.setSelectionRange(index, index);
  }, position);
}
for (const engine of engines) {
  test(`${engine}: actual Chromium browser editing gate`, {timeout:180000}, async t => {
    const browserA = await chromium.launch({headless:true, args:['--no-sandbox']});
    const browserB = await chromium.launch({headless:true, args:['--no-sandbox']});
    t.after(async()=>{await browserA.close();await browserB.close();});
    await t.test('real keystrokes update model incrementally and browser Undo remains coherent', async () => {
      const {page,context}=await newPage(browserA,engine);
      await context.setOffline(true);
      await moveCaret(page,'start');
      await page.keyboard.type('Please ',{delay:15});
      const result=await state(page);
      assert.equal(result.body, 'Please Review supplier before processing payment.');
      assert.ok(result.commandCount>=6, `expected per-keystroke edits; got ${result.commandCount}`);
      assert.deepEqual(await H(page,'errors'),[]);
      await page.keyboard.press('Control+z');
      const afterUndo=await state(page);
      assert.equal(afterUndo.body,await page.locator('#body').inputValue());
      assert.deepEqual(await H(page,'errors'),[]);
      await context.close();
    });
    await t.test('grapheme-bearing text preserves selected passage identity through edit and new browser reopen', async () => {
      const {page,context}=await newPage(browserA,engine);
      await select(page,'supplier');
      assert.equal((await H(page,'captureAnchor')).status,'captured');
      await moveCaret(page,'start');
      await page.keyboard.insertText('🦉e\u0301 ');
      const current=await state(page);
      assert.equal(current.body,'🦉e\u0301 Review supplier before processing payment.');
      const beforeSave=await H(page,'resolveAnchor');
      assert.equal(beforeSave.status,'valid', JSON.stringify(beforeSave));
      assert.equal(beforeSave.selected,'supplier');
      const saved=await H(page,'persist');
      assert.equal(saved.status,'saved');
      const temp=await fs.mkdtemp(path.join(os.tmpdir(),'pocket-crdt-editor-'));
      const disk=path.join(temp,'snapshot.json');
      await fs.writeFile(disk,JSON.stringify(saved.snapshot));
      const reopened=JSON.parse(await fs.readFile(disk,'utf8'));
      const newContext=await browserB.newContext();
      const newWindow=await newContext.newPage();
      await newWindow.goto(pageURL(engine));
      assert.equal((await H(newWindow,'reopen',[reopened])).status,'opened');
      assert.equal((await H(newWindow,'resolveAnchor')).status,'valid');
      assert.equal((await state(newWindow)).body,current.body);
      await newContext.close();await fs.rm(temp,{recursive:true,force:true});
      await context.close();
    });
    await t.test('deleting selected passage makes promotion fail closed, not attach to adjacent words',async()=>{
      const {page,context}=await newPage(browserA,engine);
      await select(page,'supplier');
      await H(page,'captureAnchor');
      await select(page,'supplier');
      await page.keyboard.press('Backspace');
      const resolved=await H(page,'resolveAnchor');
      assert.equal(resolved.status,'hold',JSON.stringify(resolved));
      const promoted=await H(page,'promote');
      assert.equal(promoted.status,'hold');
      assert.equal((await state(page)).ideas['idea-23'],undefined);
      assert.deepEqual(await H(page,'errors'),[]);
      await context.close();
    });
    await t.test('Chromium CDP composition input commits Japanese text without duplicate or partial semantic edits',async()=>{
      const {page,context}=await newPage(browserA,engine);
      await moveCaret(page,'end');
      const before=(await state(page)).commandCount;
      const session=await context.newCDPSession(page);
      await session.send('Input.imeSetComposition',{text:'日本',selectionStart:2,selectionEnd:2,replacementStart:-1,replacementEnd:-1});
      await session.send('Input.imeSetComposition',{text:'日本語',selectionStart:3,selectionEnd:3,replacementStart:-1,replacementEnd:-1});
      await session.send('Input.insertText',{text:'日本語'});
      await page.waitForTimeout(100);
      const current=await state(page);
      const expected='Review supplier before processing payment.日本語';
      assert.equal(await page.locator('#body').inputValue(),expected);
      assert.equal(current.body,expected,JSON.stringify({current,events:await H(page,'events')}));
      assert.equal(current.commandCount-before,1,'IME composition should be one accepted semantic edit');
      assert.deepEqual(await H(page,'errors'),[]);
      const events=await H(page,'events');
      assert.ok(events.some(x=>x.event==='compositionstart'),JSON.stringify(events));
      assert.ok(events.some(x=>x.event==='compositionend'),JSON.stringify(events));
      console.log('CDP_IME_EVENT_SEQUENCE='+engine+':'+JSON.stringify(events.map(x=>x.event)));
      await session.detach();await context.close();
    });
    await t.test('independent offline Chromium processes reconcile unrelated edits and keep their exact targets',async()=>{
      const {page:a,context:ca}=await newPage(browserA,engine);
      const {page:b,context:cb}=await newPage(browserB,engine);
      const base=await H(a,'exportBytes');
      await H(b,'importBytes',[base,'replace']);
      await H(a,'setActor',['A']);await H(b,'setActor',['B']);
      await ca.setOffline(true);await cb.setOffline(true);
      await select(a,'supplier');await a.keyboard.insertText('Blackwoods');
      await H(a,'makeReference',['ref-44','creditor:blackwoods']);
      await select(b,'payment');await b.keyboard.insertText('invoice');
      const beforeA=await H(a,'exportBytes');const beforeB=await H(b,'exportBytes');
      await H(a,'importBytes',[beforeB,'merge']);await H(b,'importBytes',[beforeA,'merge']);
      const resultA=await state(a),resultB=await state(b);
      assert.equal(resultA.body,resultB.body);
      assert.equal(resultA.body,'Review Blackwoods before processing invoice.');
      assert.equal(resultA.references['ref-44'].targetId,'creditor:blackwoods');
      assert.equal(resultB.references['ref-44'].targetId,'creditor:blackwoods');
      assert.deepEqual(await H(a,'errors'),[]);assert.deepEqual(await H(b,'errors'),[]);
      await ca.close();await cb.close();
    });
    await t.test('promotion Undo is refused after a different offline editor changes the nested idea',async()=>{
      const {page:a,context:ca}=await newPage(browserA,engine);
      const {page:b,context:cb}=await newPage(browserB,engine);
      await H(a,'setActor',['A']);await H(b,'setActor',['B']);
      await ca.setOffline(true);await cb.setOffline(true);
      await select(a,'supplier');
      await H(a,'captureAnchor');
      const promoted=await H(a,'promote');assert.equal(promoted.status,'ready');
      assert.equal((await state(a)).ideas['idea-23'].id,'idea-23');
      const promotedBytes=await H(a,'exportBytes');
      await H(b,'importBytes',[promotedBytes,'replace']);
      await b.locator('#child').focus();
      await b.locator('#child').evaluate(el=>{el.setSelectionRange(el.value.length,el.value.length)});
      await b.keyboard.type(' from B',{delay:10});
      const updatedB=await state(b);assert.equal(updatedB.ideas['idea-23'].lastEditor,'B');
      await H(a,'importBytes',[await H(b,'exportBytes'),'merge']);
      const undo=await H(a,'undoPromotion');
      assert.equal(undo.status,'hold',JSON.stringify(undo));
      assert.equal(undo.reason,'dependent-work-would-be-destroyed');
      const after=await state(a);
      assert.equal(after.ideas['idea-23'].text,'Check approval from B');
      assert.equal(after.ideas['idea-23'].id,'idea-23');
      assert.equal(after.body,'Review supplier before processing payment.');
      await ca.close();await cb.close();
    });
  });
}

import * as Y from 'yjs';
import * as A from '@automerge/automerge';

const SOURCE = 'Review supplier before processing payment.';
const engine = new URLSearchParams(location.search).get('engine');
if (!['yjs', 'automerge'].includes(engine)) throw new Error('Unknown engine');
const body = document.querySelector('#body');
const child = document.querySelector('#child');
const note = document.querySelector('#note');
const saveBtn = document.querySelector('#save');
const anchorBtn = document.querySelector('#anchor');
const promoteBtn = document.querySelector('#promote');
const undoBtn = document.querySelector('#undo');
let doc, snap = null, anchor = null, composition = false, pendingComposition = null, dirty = false;
let actor = 'A';
let commandCount = 0;
const eventLog = [];
const errors = [];
const record = (event, detail = '') => eventLog.push({event, detail: String(detail).slice(0, 90)});
const initial = () => {
  if (engine === 'yjs') {
    doc = new Y.Doc({guid: 'pocket-research'});
    doc.getText('body').insert(0, SOURCE);
  } else {
    doc = A.from({body: SOURCE, ideas: {}, references: {}});
  }
};
initial();
const read = () => engine === 'yjs' ? doc.getText('body').toString() : doc.body;
const ideas = () => engine === 'yjs' ? Object.fromEntries(doc.getMap('ideas').entries()) : doc.ideas;
const findIdea = (id = 'idea-23') => ideas()[id] ?? null;
const isDirty = () => dirty;
function modifyBody(next) {
  const prior = read();
  if (prior === next) return;
  let left = 0;
  while (left < prior.length && left < next.length && prior[left] === next[left]) left++;
  let right = 0;
  while (right < prior.length - left && right < next.length - left && prior[prior.length - right - 1] === next[next.length - right - 1]) right++;
  const removed = prior.length - left - right;
  const inserted = next.slice(left, next.length - right);
  if (engine === 'yjs') {
    doc.transact(() => { doc.getText('body').delete(left, removed); doc.getText('body').insert(left, inserted); }, actor);
  } else {
    doc = A.change(doc, draft => A.splice(draft, ['body'], left, removed, inserted));
  }
  commandCount++;
  dirty = true;
  if (read() !== next) {
    errors.push({kind: 'text-mismatch', prior, next, actual: read(), left, removed, inserted});
  }
  record('committed-edit', `${left}:${removed}:${inserted}`);
}
function render({forceBody = false} = {}) {
  if (forceBody || (!composition && document.activeElement !== body)) body.value = read();
  const idea = findIdea();
  child.hidden = !idea;
  if (idea && document.activeElement !== child) child.value = idea.text;
  note.textContent = `${engine} · ${dirty ? 'unsaved' : 'saved'} · ${idea ? 'idea present' : 'no idea'}`;
}
body.addEventListener('compositionstart', () => { composition = true; pendingComposition = body.value; record('compositionstart'); });
body.addEventListener('compositionupdate', event => record('compositionupdate', event.data));
body.addEventListener('compositionend', event => {
  record('compositionend', event.data);
  composition = false;
  setTimeout(() => { if (!composition) { modifyBody(body.value); pendingComposition = null; render(); } }, 0);
});
body.addEventListener('beforeinput', event => record('beforeinput', `${event.inputType}:${event.data ?? ''}`));
body.addEventListener('input', event => {
  record('input', `${event.inputType}:${event.data ?? ''}`);
  if (!composition && !event.isComposing) modifyBody(body.value);
});
child.addEventListener('input', () => {
  const before = findIdea();
  if (!before) return;
  const updated = {...before, text: child.value, lastEditor: actor, revision: (before.revision ?? 0) + 1};
  if (engine === 'yjs') doc.getMap('ideas').set('idea-23', updated);
  else doc = A.change(doc, d => { d.ideas['idea-23'] = updated; });
  dirty = true;
  record('idea-edit', updated.text);
});
function captureAnchor() {
  const start = body.selectionStart, end = body.selectionEnd;
  if (!(start >= 0 && end > start)) return {status: 'hold', reason: 'no-selection'};
  const selected = read().slice(start, end);
  anchor = engine === 'yjs' ? {
    kind: engine, expected: selected,
    start: Array.from(Y.encodeRelativePosition(Y.createRelativePositionFromTypeIndex(doc.getText('body'), start))),
    end: Array.from(Y.encodeRelativePosition(Y.createRelativePositionFromTypeIndex(doc.getText('body'), end)))
  } : {
    kind: engine, expected: selected,
    start: A.getCursor(doc, ['body'], start), end: A.getCursor(doc, ['body'], end)
  };
  record('anchor', selected);
  return {status: 'captured', selected};
}
function resolveAnchor() {
  if (!anchor) return {status: 'hold', reason: 'no-anchor'};
  let start, end;
  try {
    if (engine === 'yjs') {
      const yText = doc.getText('body');
      const x = Y.createAbsolutePositionFromRelativePosition(Y.decodeRelativePosition(Uint8Array.from(anchor.start)), doc);
      const z = Y.createAbsolutePositionFromRelativePosition(Y.decodeRelativePosition(Uint8Array.from(anchor.end)), doc);
      if (!x || !z || x.type !== yText || z.type !== yText) return {status: 'hold', reason: 'anchor-unavailable'};
      start = x.index; end = z.index;
    } else {
      start = A.getCursorPosition(doc, ['body'], anchor.start);
      end = A.getCursorPosition(doc, ['body'], anchor.end);
    }
  } catch (error) { return {status: 'hold', reason: 'anchor-unavailable', error: String(error)}; }
  const actual = read().slice(start, end);
  return actual === anchor.expected ? {status: 'valid', selected: actual, start, end} : {status: 'hold', reason: 'selected-content-changed', actual, expected: anchor.expected, start, end};
}
function promote() {
  const resolved = resolveAnchor();
  if (resolved.status !== 'valid') return {status: 'hold', reason: 'selection-not-current', resolved};
  if (findIdea()) return {status: 'hold', reason: 'existing-idea'};
  const idea = {id:'idea-23', parentId:'note-1', text:'Check approval', originSelection:resolved.selected, creator:actor, lastEditor:actor, revision:1};
  if (engine === 'yjs') doc.getMap('ideas').set(idea.id, idea);
  else doc = A.change(doc, d => {d.ideas[idea.id] = idea;});
  dirty=true;record('promote', idea.id);render();
  return {status:'ready', ideaId:idea.id};
}
function undoPromotion() {
  const item = findIdea();
  if (!item) return {status:'hold',reason:'idea-missing'};
  if (item.lastEditor !== item.creator || item.revision !== 1 || Object.values(ideas()).some(x => x.parentId === item.id)) {
    record('undo-blocked', item.id);
    return {status:'hold',reason:'dependent-work-would-be-destroyed',idea:item};
  }
  if (engine === 'yjs') doc.getMap('ideas').delete(item.id);
  else doc=A.change(doc,d=>{delete d.ideas[item.id];});
  dirty=true;record('undo-accepted', item.id);render();
  return {status:'ready'};
}
function exportBytes() {return Array.from(engine === 'yjs' ? Y.encodeStateAsUpdate(doc) : A.save(doc));}
function importBytes(bytes, mode = 'replace') {
  const typed=Uint8Array.from(bytes);
  if (engine === 'yjs') {
    if(mode === 'replace') {doc.destroy();doc = new Y.Doc({guid:'pocket-research'});}
    Y.applyUpdate(doc,typed,'remote');
  } else if(mode === 'replace') doc=A.load(typed);
  else doc=A.merge(doc,A.load(typed));
  dirty = mode === 'merge';
  render({forceBody:true});
}
function persist() {
  if (composition) return {status:'hold',reason:'composing'};
  modifyBody(body.value);
  snap={bytes:exportBytes(), anchor: anchor === null ? null : structuredClone(anchor)};
  dirty=false;record('save');render();
  return {status:'saved', snapshot:structuredClone(snap)};
}
function reopen(bundle) {
  if (!bundle?.bytes) return {status:'hold',reason:'missing-snapshot'};
  importBytes(bundle.bytes, 'replace');
  anchor=bundle.anchor ? structuredClone(bundle.anchor) : null;
  snap=structuredClone(bundle);
  dirty=false;record('reopen');render({forceBody:true});
  return {status:'opened'};
}
function makeReference(id='ref-44', targetId='creditor:blackwoods') {
  if (engine==='yjs') doc.getMap('references').set(id,{id,targetId});
  else doc=A.change(doc,d=>{d.references[id]={id,targetId};});
  dirty=true;record('reference',targetId);return {status:'ready'};
}
const references=()=> engine==='yjs' ? Object.fromEntries(doc.getMap('references').entries()):doc.references;
anchorBtn.addEventListener('click',captureAnchor);
promoteBtn.addEventListener('click',promote);
undoBtn.addEventListener('click',undoPromotion);
saveBtn.addEventListener('click',persist);
window.pocketResearch = {
  engine, source:SOURCE,
  setActor(value){actor=value;},
  events:()=>structuredClone(eventLog), errors:()=>structuredClone(errors),
  state:()=>({body:read(),ideas:structuredClone(ideas()),references:structuredClone(references()),dirty,commandCount,composition,pendingComposition}),
  captureAnchor,resolveAnchor,promote,undoPromotion,persist,reopen,
  exportBytes,importBytes,makeReference,
  snapshot:()=>snap ? structuredClone(snap):null
};
render({forceBody:true});
